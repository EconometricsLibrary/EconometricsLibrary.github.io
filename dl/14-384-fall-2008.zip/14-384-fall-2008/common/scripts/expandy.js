 
	$(document).ready(function() { 

		$('div.toggle1').hide(); 
		$('div.reveal1').click(function() { 
			$('div.toggle1').slideToggle(400);
			return false; 
		});

		$('div.toggle2').hide(); 
		$('div.reveal2').click(function() { 
			$('div.toggle2').slideToggle(400);
			return false; 
		});

		$('div.toggle3').hide(); 
		$('div.reveal3').click(function() { 
			$('div.toggle3').slideToggle(400);
			return false; 
		});

		$('div.toggle4').hide(); 
		$('div.reveal4').click(function() { 
			$('div.toggle4').slideToggle(400);
			return false; 
		});

		$('div.toggle5').hide(); 
		$('div.reveal5').click(function() { 
			$('div.toggle5').slideToggle(400);
			return false; 
		});

		$('div.toggle6').hide(); 
		$('div.reveal6').click(function() { 
			$('div.toggle6').slideToggle(400);
			return false; 
		});

		$('div.toggle7').hide(); 
		$('div.reveal7').click(function() { 
			$('div.toggle7').slideToggle(400);
			return false; 
		});

		$('div.toggle8').hide(); 
		$('div.reveal8').click(function() { 
			$('div.toggle8').slideToggle(400);
			return false; 
		});

		$('div.toggle9').hide(); 
		$('div.reveal9').click(function() { 
			$('div.toggle9').slideToggle(400);
			return false; 
		});

		$('div.toggle10').hide(); 
		$('div.reveal10').click(function() { 
			$('div.toggle10').slideToggle(400);
			return false; 
		});
});
